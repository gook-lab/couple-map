import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/today");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-couple-blue-010 via-white to-couple-blue-020 flex items-center justify-center section-padding">
      <div className="container-mobile">
        <Card className="shadow-xl border-0">
          <CardHeader className="text-center space-y-4">
            <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-couple-blue-070 to-couple-blue-080 rounded-full flex items-center justify-center mx-auto">
              <Heart className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
            <CardTitle className="couple-title-20 sm:couple-title-24 text-couple-gray-100">
              우리의 여행 일기
            </CardTitle>
            <CardDescription className="couple-text-12-400 sm:couple-text-14-400 text-couple-gray-060">
              둘만의 특별한 순간을 기록하세요
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label
                  htmlFor="email"
                  className="couple-text-12-500 sm:couple-text-14-500 text-couple-gray-080"
                >
                  이메일
                </label>
                <Input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="couple@example.com"
                  className="h-10 sm:h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <label
                  htmlFor="password"
                  className="couple-text-12-500 sm:couple-text-14-500 text-couple-gray-080"
                >
                  비밀번호
                </label>
                <Input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-10 sm:h-11"
                  required
                />
              </div>

              <div className="flex items-center justify-between text-xs sm:text-sm">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    className="w-3 h-3 sm:w-4 sm:h-4 text-couple-blue-070 border-couple-gray-030 rounded focus:ring-couple-blue-030"
                  />
                  <span className="couple-text-12-400 sm:couple-text-14-400 text-couple-gray-070">
                    로그인 유지
                  </span>
                </label>
                <Button
                  type="button"
                  variant="link"
                  size="sm"
                  className="p-0 h-auto couple-text-12-500 sm:couple-text-14-500 text-couple-blue-070 hover:text-couple-blue-080"
                >
                  비밀번호 찾기
                </Button>
              </div>

              <Button type="submit" className="w-full h-10 sm:h-11" size="lg">
                로그인
              </Button>

              <div className="text-center pt-4 border-t border-couple-gray-020">
                <span className="couple-text-12-400 sm:couple-text-14-400 text-couple-gray-060">
                  아직 계정이 없으신가요?{" "}
                </span>
                <Button
                  type="button"
                  variant="link"
                  size="sm"
                  className="p-0 h-auto couple-text-12-600 sm:couple-text-14-600 text-couple-blue-070 hover:text-couple-blue-080"
                >
                  회원가입
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Login;
