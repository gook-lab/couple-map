import React from "react";
import {
  Settings,
  Heart,
  Camera,
  MapPin,
  Calendar,
  LogOut,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Profile: React.FC = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/");
  };

  const profileStats = [
    { icon: <MapPin className="w-4 h-4" />, label: "방문한 장소", value: "12" },
    { icon: <Camera className="w-4 h-4" />, label: "사진", value: "156" },
    {
      icon: <Calendar className="w-4 h-4" />,
      label: "함께한 날",
      value: "365",
    },
    { icon: <Heart className="w-4 h-4" />, label: "추억", value: "89" },
  ];

  const menuItems = [
    {
      icon: <Heart className="w-5 h-5" />,
      label: "우리의 기념일",
      action: () => {},
    },
    { icon: <Camera className="w-5 h-5" />, label: "사진첩", action: () => {} },
    {
      icon: <MapPin className="w-5 h-5" />,
      label: "즐겨찾기 장소",
      action: () => {},
    },
    { icon: <Settings className="w-5 h-5" />, label: "설정", action: () => {} },
  ];

  return (
    <div className="min-h-screen bg-couple-gray-005">
      <header className="bg-gradient-to-r from-couple-blue-070 to-couple-blue-080 text-white">
        <div className="px-4 py-8">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="couple-title-20 text-white">우리 커플</h1>
              <p className="couple-text-14-400 text-white/80 mt-1">
                함께한 지 365일째
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="p-4">
        <div className="grid grid-cols-4 gap-2 mb-6 -mt-8">
          {profileStats.map((stat, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-3 shadow-sm text-center"
            >
              <div className="flex justify-center text-couple-blue-070 mb-2">
                {stat.icon}
              </div>
              <div className="couple-title-16 text-couple-gray-090">
                {stat.value}
              </div>
              <div className="couple-text-10-400 text-couple-gray-060">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={item.action}
              className="w-full card-hover flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-couple-blue-020 rounded-lg flex items-center justify-center text-couple-blue-070">
                {item.icon}
              </div>
              <span className="couple-text-16-500 text-couple-gray-090 flex-1 text-left">
                {item.label}
              </span>
            </button>
          ))}
        </div>

        <button
          onClick={handleLogout}
          className="w-full mt-8 flex items-center justify-center gap-2 py-3 text-couple-status-red couple-text-16-500"
        >
          <LogOut className="w-5 h-5" />
          <span>로그아웃</span>
        </button>
      </div>
    </div>
  );
};

export default Profile;
