import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Calendar, Heart, Clock } from 'lucide-react'
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore'
import { db } from '../lib/firebase'
import { format } from 'date-fns'
import { ko } from 'date-fns/locale'

interface Photo {
  id: string
  url: string
  caption: string
  userEmail: string
  createdAt: any
}

export default function Timeline() {
  const [photos, setPhotos] = useState<Photo[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const q = query(collection(db, 'photos'), orderBy('createdAt', 'desc'))
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const photoData: Photo[] = []
      snapshot.forEach((doc) => {
        photoData.push({ id: doc.id, ...doc.data() } as Photo)
      })
      setPhotos(photoData)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-gray-500">로딩 중...</div>
      </div>
    )
  }

  return (
    <div className="p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <div className="flex items-center gap-3 mb-8">
          <Clock className="text-pink-500" size={32} />
          <div>
            <h1 className="text-3xl font-bold text-gray-800">타임라인</h1>
            <p className="text-gray-600">우리의 소중한 순간들</p>
          </div>
        </div>

        {photos.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <Calendar className="mx-auto h-16 w-16 text-gray-300 mb-4" />
            <p className="text-lg text-gray-600">아직 공유된 사진이 없어요</p>
            <p className="text-sm text-gray-500 mt-2">첫 번째 추억을 만들어보세요!</p>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-pink-200"></div>
            
            <div className="space-y-8">
              {photos.map((photo, index) => (
                <motion.div
                  key={photo.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex gap-6 relative"
                >
                  <div className="w-16 flex-shrink-0 relative">
                    <div className="w-4 h-4 bg-pink-500 rounded-full absolute left-0 top-2"></div>
                  </div>
                  
                  <div className="flex-1 bg-white rounded-xl shadow-lg overflow-hidden">
                    <img
                      src={photo.url}
                      alt={photo.caption}
                      className="w-full h-64 object-cover"
                    />
                    <div className="p-6">
                      {photo.caption && (
                        <p className="text-gray-800 mb-3">{photo.caption}</p>
                      )}
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Heart size={14} className="text-pink-400" />
                          {photo.userEmail}
                        </span>
                        {photo.createdAt && (
                          <span>
                            {format(photo.createdAt.toDate(), 'PPP p', { locale: ko })}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  )
}