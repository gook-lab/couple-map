import { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { Send, Heart } from 'lucide-react'
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore'
import { db } from '../lib/firebase'
import { useAuth } from '../contexts/AuthContext'
import { format } from 'date-fns'

interface Message {
  id: string
  text: string
  userId: string
  userEmail: string
  createdAt: any
}

export default function Chat() {
  const { user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    const q = query(collection(db, 'messages'), orderBy('createdAt', 'asc'))
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messageData: Message[] = []
      snapshot.forEach((doc) => {
        messageData.push({ id: doc.id, ...doc.data() } as Message)
      })
      setMessages(messageData)
      scrollToBottom()
    })

    return () => unsubscribe()
  }, [])

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim() || !user || sending) return

    setSending(true)
    const messageText = newMessage
    setNewMessage('')

    try {
      await addDoc(collection(db, 'messages'), {
        text: messageText,
        userId: user.uid,
        userEmail: user.email,
        createdAt: serverTimestamp()
      })
    } catch (error) {
      console.error('Error sending message:', error)
      setNewMessage(messageText)
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="h-screen flex flex-col">
      <div className="bg-white shadow-sm p-6 border-b">
        <div className="flex items-center gap-3">
          <Heart className="text-pink-500" size={28} />
          <div>
            <h1 className="text-2xl font-bold text-gray-800">채팅</h1>
            <p className="text-sm text-gray-600">우리만의 대화 공간</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">첫 메시지를 보내보세요! 💌</p>
            </div>
          ) : (
            messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex ${message.userId === user?.uid ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                    message.userId === user?.uid
                      ? 'bg-pink-500 text-white'
                      : 'bg-white text-gray-800 shadow-md'
                  }`}
                >
                  <p className="break-words">{message.text}</p>
                  <div className={`text-xs mt-2 ${
                    message.userId === user?.uid ? 'text-pink-100' : 'text-gray-500'
                  }`}>
                    <span className="block">{message.userEmail}</span>
                    {message.createdAt && (
                      <span>
                        {format(message.createdAt.toDate(), 'HH:mm')}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <form onSubmit={sendMessage} className="bg-white border-t p-4">
        <div className="max-w-3xl mx-auto flex gap-3">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="메시지를 입력하세요..."
            className="flex-1 px-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!newMessage.trim() || sending}
            className="bg-pink-500 text-white p-3 rounded-full hover:bg-pink-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  )
}