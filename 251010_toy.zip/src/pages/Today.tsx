import React, { useState } from "react";
import { Calendar as CalendarIcon, MapPin, Camera, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";

const Today: React.FC = () => {
  const today = new Date().toLocaleDateString("ko-KR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const [memories] = useState([
    {
      id: 1,
      time: "오전 10:00",
      location: "서울 남산타워",
      description: "멋진 전망과 함께한 브런치",
      image: null,
    },
    {
      id: 2,
      time: "오후 2:30",
      location: "한강공원",
      description: "자전거 타기",
      image: null,
    },
  ]);

  return (
    <div className="min-h-screen bg-couple-gray-005">
      <header className="bg-white shadow-sm border-b border-couple-gray-020">
        <div className="header-mobile">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="couple-title-18 sm:couple-title-20 text-couple-gray-100">
                오늘의 여행
              </h1>
              <p className="couple-text-12-400 sm:couple-text-14-400 text-couple-gray-060 mt-1">
                {today}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 sm:w-5 sm:h-5 text-couple-blue-070" />
            </div>
          </div>
        </div>
      </header>

      <div className="section-padding space-y-4 sm:space-y-6">
        <Card className="bg-gradient-to-r from-couple-blue-070 to-couple-blue-080 text-white border-0">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center gap-2 sm:gap-3 mb-2 sm:mb-3">
              <Heart className="w-5 h-5 sm:w-6 sm:h-6" />
              <span className="couple-text-14-600 sm:couple-text-16-600">
                오늘의 기록
              </span>
            </div>
            <p className="couple-text-12-400 sm:couple-text-14-400 opacity-90">
              함께한 모든 순간이 특별해요
            </p>
          </CardContent>
        </Card>

        <Button className="w-full h-12 sm:h-14" size="lg">
          <Camera className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
          <span className="couple-text-14-600 sm:couple-text-16-600">
            오늘의 추억 추가하기
          </span>
        </Button>

        <div className="space-y-3 sm:space-y-4">
          <h2 className="couple-title-16 sm:couple-title-18 text-couple-gray-090">
            타임라인
          </h2>

          {memories.map((memory) => (
            <Card
              key={memory.id}
              className="hover:shadow-lg hover:border-couple-blue-040 transition-all active:scale-[0.98]"
            >
              <CardContent className="p-3 sm:p-4">
                <div className="flex items-start gap-2 sm:gap-3">
                  <div className="w-2 h-2 bg-couple-blue-070 rounded-full mt-2"></div>
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2 mb-2">
                      <span className="couple-text-12-600 sm:couple-text-14-600 text-couple-gray-090">
                        {memory.time}
                      </span>
                      <div className="flex items-center gap-1 text-couple-gray-060">
                        <MapPin className="w-3 h-3" />
                        <span className="couple-text-10-400 sm:couple-text-12-400">
                          {memory.location}
                        </span>
                      </div>
                    </div>
                    <p className="couple-text-12-400 sm:couple-text-14-400 text-couple-gray-070">
                      {memory.description}
                    </p>
                    {memory.image && (
                      <div className="mt-2 sm:mt-3 rounded-lg overflow-hidden">
                        <img src={memory.image} alt="" className="w-full" />
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-couple-blue-010">
          <CardContent className="p-4 sm:p-6">
            <h3 className="couple-title-14 sm:couple-title-16 text-couple-gray-090 mb-3 sm:mb-4">
              오늘의 통계
            </h3>
            <div className="grid grid-cols-3 gap-3 sm:gap-4">
              <div className="text-center">
                <div className="couple-title-20 sm:couple-title-24 text-couple-blue-070">
                  2
                </div>
                <div className="couple-text-10-400 sm:couple-text-12-400 text-couple-gray-060">
                  방문한 장소
                </div>
              </div>
              <div className="text-center">
                <div className="couple-title-20 sm:couple-title-24 text-couple-blue-070">
                  0
                </div>
                <div className="couple-text-10-400 sm:couple-text-12-400 text-couple-gray-060">
                  찍은 사진
                </div>
              </div>
              <div className="text-center">
                <div className="couple-title-20 sm:couple-title-24 text-couple-blue-070">
                  4.5
                </div>
                <div className="couple-text-10-400 sm:couple-text-12-400 text-couple-gray-060">
                  함께한 시간
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Today;
