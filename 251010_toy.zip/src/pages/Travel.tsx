import React, { useState } from "react";
import { ChevronRight, Globe, Map } from "lucide-react";
import MapSelector from "@/components/maps/MapSelector";
import type { MapType } from "@/components/maps/MapSelector";

interface MapOption {
  id: MapType;
  name: string;
  description: string;
  icon: React.ReactNode;
}

const Travel: React.FC = () => {
  const [selectedMap, setSelectedMap] = useState<MapType | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<{
    type: MapType;
    region?: string;
    regionName?: string;
  } | null>(null);

  const mapOptions: MapOption[] = [
    {
      id: "korea",
      name: "대한민국",
      description: "전국 시도별 여행 기록",
      icon: <Map className="w-5 h-5" />,
    },
    {
      id: "seoul",
      name: "서울",
      description: "서울 구별 여행 기록",
      icon: <Map className="w-5 h-5" />,
    },
    {
      id: "jeju",
      name: "제주도",
      description: "제주 지역별 여행 기록",
      icon: <Map className="w-5 h-5" />,
    },
    {
      id: "japan",
      name: "일본",
      description: "일본 지역별 여행 기록",
      icon: <Globe className="w-5 h-5" />,
    },
  ];

  const stats = {
    totalPlaces: 12,
    countries: 3,
    cities: 8,
    photos: 156,
  };

  return (
    <div className="min-h-screen bg-couple-gray-005">
      <header className="bg-white shadow-sm border-b border-couple-gray-020">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="couple-title-20 text-couple-gray-100">
                나의 여행
              </h1>
              <p className="couple-text-14-400 text-couple-gray-060 mt-1">
                우리가 함께 다녀온 모든 곳
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="p-4">
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="card">
            <div className="couple-text-12-500 text-couple-gray-060 mb-1">
              방문한 장소
            </div>
            <div className="couple-title-24 text-couple-blue-070">
              {stats.totalPlaces}
            </div>
          </div>
          <div className="card">
            <div className="couple-text-12-500 text-couple-gray-060 mb-1">
              방문 국가
            </div>
            <div className="couple-title-24 text-couple-blue-070">
              {stats.countries}
            </div>
          </div>
          <div className="card">
            <div className="couple-text-12-500 text-couple-gray-060 mb-1">
              도시
            </div>
            <div className="couple-title-24 text-couple-blue-070">
              {stats.cities}
            </div>
          </div>
          <div className="card">
            <div className="couple-text-12-500 text-couple-gray-060 mb-1">
              사진
            </div>
            <div className="couple-title-24 text-couple-blue-070">
              {stats.photos}
            </div>
          </div>
        </div>

        <div>
          <h2 className="couple-title-18 text-couple-gray-090 mb-4">
            지도 선택
          </h2>
          <div className="space-y-3">
            {mapOptions.map((option) => (
              <button
                key={option.id}
                onClick={() => setSelectedMap(option.id)}
                className="w-full card-hover flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-couple-blue-020 rounded-lg flex items-center justify-center text-couple-blue-070 group-hover:bg-couple-blue-030">
                    {option.icon}
                  </div>
                  <div className="text-left">
                    <h3 className="couple-text-16-600 text-couple-gray-090">
                      {option.name}
                    </h3>
                    <p className="couple-text-12-400 text-couple-gray-060">
                      {option.description}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-couple-gray-040 group-hover:text-couple-blue-070" />
              </button>
            ))}
          </div>
        </div>

        {selectedLocation && (
          <div className="mt-6 p-4 bg-couple-blue-010 rounded-lg">
            <h3 className="couple-text-16-600 text-couple-blue-070 mb-2">
              최근 선택한 위치
            </h3>
            <p className="couple-text-14-400 text-couple-gray-090">
              {selectedLocation.regionName} ({mapOptions.find(opt => opt.id === selectedLocation.type)?.name})
            </p>
          </div>
        )}

        {selectedMap && (
          <div 
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedMap(null)}
          >
            <div 
              className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="couple-title-20 text-couple-gray-100">
                    {mapOptions.find((m) => m.id === selectedMap)?.name} 지도
                  </h2>
                  <button
                    onClick={() => setSelectedMap(null)}
                    className="text-couple-gray-060 hover:text-couple-gray-090"
                  >
                    ✕
                  </button>
                </div>
                <MapSelector
                  onLocationSelect={(location) => {
                    setSelectedLocation(location);
                    // 위치 선택 후 잠시 후 모달 닫기
                    setTimeout(() => {
                      setSelectedMap(null);
                    }, 1500);
                  }}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Travel;
