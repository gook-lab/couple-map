import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import { Upload, Heart, Send } from 'lucide-react'
import { storage, db } from '../lib/firebase'
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'
import { collection, addDoc, serverTimestamp } from 'firebase/firestore'
import { useAuth } from '../contexts/AuthContext'

export default function Home() {
  const { user } = useAuth()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [caption, setCaption] = useState('')

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleUpload = async () => {
    if (!selectedFile || !user) return

    setUploading(true)
    try {
      const timestamp = Date.now()
      const fileName = `${user.uid}_${timestamp}_${selectedFile.name}`
      const storageRef = ref(storage, `photos/${fileName}`)
      
      const snapshot = await uploadBytes(storageRef, selectedFile)
      const downloadURL = await getDownloadURL(snapshot.ref)
      
      await addDoc(collection(db, 'photos'), {
        url: downloadURL,
        caption,
        userId: user.uid,
        userEmail: user.email,
        createdAt: serverTimestamp(),
        fileName
      })

      setSelectedFile(null)
      setPreview(null)
      setCaption('')
      alert('사진이 성공적으로 업로드되었습니다!')
    } catch (error) {
      console.error('Upload error:', error)
      alert('업로드 중 오류가 발생했습니다')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto"
      >
        <h1 className="text-3xl font-bold text-gray-800 mb-2">홈</h1>
        <p className="text-gray-600 mb-8">소중한 순간을 공유해보세요 💕</p>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          {!preview ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center cursor-pointer hover:border-pink-400 transition-colors"
            >
              <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-lg font-medium text-gray-700">사진 선택하기</p>
              <p className="text-sm text-gray-500 mt-2">클릭하거나 드래그해서 업로드</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative rounded-xl overflow-hidden">
                <img
                  src={preview}
                  alt="Preview"
                  className="w-full h-auto max-h-96 object-contain bg-gray-50"
                />
                <button
                  onClick={() => {
                    setPreview(null)
                    setSelectedFile(null)
                  }}
                  className="absolute top-4 right-4 bg-white/90 p-2 rounded-lg hover:bg-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  메시지 추가하기
                </label>
                <textarea
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent resize-none"
                  rows={3}
                  placeholder="이 순간에 대해 이야기해주세요..."
                />
              </div>

              <button
                onClick={handleUpload}
                disabled={uploading}
                className="w-full bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {uploading ? (
                  <>업로드 중...</>
                ) : (
                  <>
                    <Send size={20} />
                    공유하기
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        <div className="mt-8 bg-pink-50 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Heart className="text-pink-500" size={24} />
            <h2 className="text-lg font-semibold text-gray-800">오늘의 메시지</h2>
          </div>
          <p className="text-gray-600">
            서로의 일상을 공유하고, 특별한 순간들을 기록해보세요. 
            우리만의 추억이 쌓여갈거예요.
          </p>
        </div>
      </motion.div>
    </div>
  )
}