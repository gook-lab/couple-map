import { Outlet, NavLink } from "react-router-dom";
import { Home, Clock, MessageCircle, LogOut } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { motion } from "framer-motion";

export default function Layout() {
  const { logout, user } = useAuth();

  return (
    <div className="flex h-screen bg-gray-50">
      <aside className="w-64 bg-white shadow-lg">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-pink-500">Couple App 💕</h1>
          <p className="text-sm text-gray-500 mt-1">{user?.email}</p>
        </div>

        <nav className="px-4">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? "bg-pink-50 text-pink-500"
                  : "text-gray-700 hover:bg-gray-50"
              }`
            }
          >
            <Home size={20} />
            <span>홈</span>
          </NavLink>

          <NavLink
            to="/timeline"
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? "bg-pink-50 text-pink-500"
                  : "text-gray-700 hover:bg-gray-50"
              }`
            }
          >
            <Clock size={20} />
            <span>타임라인</span>
          </NavLink>

          <NavLink
            to="/chat"
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? "bg-pink-50 text-pink-500"
                  : "text-gray-700 hover:bg-gray-50"
              }`
            }
          >
            <MessageCircle size={20} />
            <span>채팅</span>
          </NavLink>
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <button
            onClick={logout}
            className="flex items-center gap-3 w-full px-4 py-3 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut size={20} />
            <span>로그아웃</span>
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Outlet />
        </motion.div>
      </main>
    </div>
  );
}
