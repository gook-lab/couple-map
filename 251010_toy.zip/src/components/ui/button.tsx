import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-couple-blue-030 disabled:pointer-events-none disabled:opacity-50 active:scale-95 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-to-r from-couple-blue-070 to-couple-blue-080 text-white shadow-lg hover:shadow-xl",
        destructive:
          "bg-couple-status-red text-white shadow-sm hover:bg-couple-status-red/90",
        outline:
          "border border-couple-gray-030 bg-white shadow-sm hover:bg-couple-gray-005 hover:border-couple-blue-070",
        secondary:
          "bg-couple-gray-010 text-couple-gray-090 shadow-sm hover:bg-couple-gray-020",
        ghost: "hover:bg-couple-gray-010 text-couple-gray-090",
        link: "text-couple-blue-070 underline-offset-4 hover:underline hover:text-couple-blue-080",
      },
      size: {
        default: "h-10 px-4 py-2 text-sm sm:h-11 sm:px-6 sm:text-base",
        sm: "h-8 px-3 text-xs sm:h-9 sm:px-4 sm:text-sm",
        lg: "h-12 px-6 text-base sm:h-14 sm:px-8 sm:text-lg",
        icon: "h-10 w-10 sm:h-11 sm:w-11",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
