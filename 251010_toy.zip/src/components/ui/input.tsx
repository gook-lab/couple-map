import * as React from "react"

import { cn } from "@/lib/utils"

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex w-full rounded-lg border border-couple-gray-030 bg-white px-3 py-2.5 text-sm text-couple-gray-100 shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-couple-gray-060 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-couple-blue-030 focus-visible:border-couple-blue-070 disabled:cursor-not-allowed disabled:opacity-50 sm:px-4 sm:py-3 sm:text-base",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }
