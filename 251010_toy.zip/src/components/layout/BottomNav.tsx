import React from "react";
import { NavLink } from "react-router-dom";
import { Calendar, Map, User } from "lucide-react";

const BottomNav: React.FC = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-couple-gray-020 z-50 safe-area-bottom">
      <div className="container-full">
        <div className="grid grid-cols-3 h-14 sm:h-16">
          <NavLink
            to="/today"
            className={({ isActive }) =>
              isActive ? "tab-item-active" : "tab-item"
            }
          >
            <Calendar className="w-4 h-4 sm:w-5 sm:h-5 mb-1" />
            <span className="hidden xs:block sm:hidden">오늘</span>
            <span className="hidden sm:block">오늘의 여행</span>
          </NavLink>

          <NavLink
            to="/travel"
            className={({ isActive }) =>
              isActive ? "tab-item-active" : "tab-item"
            }
          >
            <Map className="w-4 h-4 sm:w-5 sm:h-5 mb-1" />
            <span className="hidden xs:block sm:hidden">여행</span>
            <span className="hidden sm:block">나의 여행</span>
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              isActive ? "tab-item-active" : "tab-item"
            }
          >
            <User className="w-4 h-4 sm:w-5 sm:h-5 mb-1" />
            <span>My</span>
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default BottomNav;
