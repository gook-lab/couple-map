import React from "react";
import { Outlet } from "react-router-dom";
import BottomNav from "./BottomNav";

const MainLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-couple-gray-005">
      <main className="pb-14 sm:pb-16">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
};

export default MainLayout;
