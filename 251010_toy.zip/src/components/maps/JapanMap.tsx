import React, { useState } from 'react';
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup
} from 'react-simple-maps';

// 일본 지도 GeoJSON 데이터 (간단한 버전)
const japanGeoData = {
  type: "FeatureCollection",
  features: [
    {
      type: "Feature",
      properties: { name: "도쿄도", name_en: "Tokyo", id: "tokyo" },
      geometry: {
        type: "Polygon",
        coordinates: [[[139.5, 35.8], [140.0, 35.8], [140.0, 35.5], [139.5, 35.5], [139.5, 35.8]]]
      }
    },
    {
      type: "Feature",
      properties: { name: "오사카부", name_en: "Osaka", id: "osaka" },
      geometry: {
        type: "Polygon",
        coordinates: [[[135.3, 34.8], [135.8, 34.8], [135.8, 34.5], [135.3, 34.5], [135.3, 34.8]]]
      }
    },
    {
      type: "Feature",
      properties: { name: "교토부", name_en: "Kyoto", id: "kyoto" },
      geometry: {
        type: "Polygon",
        coordinates: [[[135.5, 35.2], [136.0, 35.2], [136.0, 34.9], [135.5, 34.9], [135.5, 35.2]]]
      }
    },
    {
      type: "Feature",
      properties: { name: "홋카이도", name_en: "Hokkaido", id: "hokkaido" },
      geometry: {
        type: "Polygon",
        coordinates: [[[140.0, 44.0], [146.0, 44.0], [146.0, 41.5], [140.0, 41.5], [140.0, 44.0]]]
      }
    },
    {
      type: "Feature",
      properties: { name: "오키나와현", name_en: "Okinawa", id: "okinawa" },
      geometry: {
        type: "Polygon",
        coordinates: [[[127.5, 26.5], [128.5, 26.5], [128.5, 25.5], [127.5, 25.5], [127.5, 26.5]]]
      }
    },
    {
      type: "Feature",
      properties: { name: "후쿠오카현", name_en: "Fukuoka", id: "fukuoka" },
      geometry: {
        type: "Polygon",
        coordinates: [[[130.0, 33.8], [131.0, 33.8], [131.0, 33.0], [130.0, 33.0], [130.0, 33.8]]]
      }
    }
  ]
};

interface JapanMapProps {
  onRegionClick?: (regionId: string, regionName: string) => void;
  selectedRegion?: string;
}

const JapanMap: React.FC<JapanMapProps> = ({ onRegionClick, selectedRegion }) => {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const handleRegionClick = (geography: any) => {
    const regionName = geography.properties.name;
    onRegionClick?.(regionName, regionName);
  };

  const getRegionColor = (regionName: string) => {
    if (selectedRegion === regionName) {
      return "rgb(31, 117, 255)"; // couple-blue-070
    }
    if (hoveredRegion === regionName) {
      return "rgb(209, 228, 255)"; // couple-blue-040
    }
    return "rgb(245, 245, 245)"; // couple-gray-010
  };

  return (
    <div className="w-full h-64 sm:h-80 bg-white rounded-lg border border-couple-gray-020">
      <ComposableMap
        projectionConfig={{
          center: [138.0, 36.0],
          scale: 1200
        }}
        width={800}
        height={600}
        className="w-full h-full"
      >
        <ZoomableGroup>
          <Geographies geography={japanGeoData}>
            {({ geographies }) =>
              geographies.map(geo => {
                const regionName = geo.properties.name;
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onClick={() => handleRegionClick(geo)}
                    onMouseEnter={() => setHoveredRegion(regionName)}
                    onMouseLeave={() => setHoveredRegion(null)}
                    style={{
                      default: {
                        fill: getRegionColor(regionName),
                        stroke: "rgb(133, 133, 133)",
                        strokeWidth: 0.5,
                        cursor: "pointer"
                      },
                      hover: {
                        fill: getRegionColor(regionName),
                        stroke: "rgb(31, 117, 255)",
                        strokeWidth: 1,
                        cursor: "pointer"
                      },
                      pressed: {
                        fill: "rgb(31, 117, 255)",
                        stroke: "rgb(31, 117, 255)",
                        strokeWidth: 1,
                        cursor: "pointer"
                      }
                    }}
                  />
                );
              })
            }
          </Geographies>
        </ZoomableGroup>
      </ComposableMap>
      
      {/* 선택된 지역 표시 */}
      {selectedRegion && (
        <div className="text-center mt-2">
          <span className="couple-text-12-500 text-couple-blue-070">
            선택된 지역: {japanGeoData.features.find(f => f.properties.id === selectedRegion)?.properties.name}
          </span>
        </div>
      )}
    </div>
  );
};

export default JapanMap;