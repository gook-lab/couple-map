import React, { useState, useEffect } from 'react';
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup
} from 'react-simple-maps';

// 서울 지도 데이터를 로드하는 함수
const loadSeoulMapData = async () => {
  try {
    const response = await fetch('/maps/seoul-districts.json');
    return await response.json();
  } catch (error) {
    console.error('서울 지도 데이터 로드 실패:', error);
    return null;
  }
};

interface SeoulMapProps {
  onRegionClick?: (regionId: string, regionName: string) => void;
  selectedRegion?: string;
}

const SeoulMap: React.FC<SeoulMapProps> = ({ onRegionClick, selectedRegion }) => {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [mapData, setMapData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      const data = await loadSeoulMapData();
      setMapData(data);
      setLoading(false);
    };
    loadData();
  }, []);

  const handleRegionClick = (geography: any) => {
    const regionName = geography.properties.SIG_KOR_NM || geography.properties.name;
    onRegionClick?.(regionName, regionName);
  };

  const getRegionColor = (regionName: string) => {
    if (selectedRegion === regionName) {
      return "rgb(31, 117, 255)"; // couple-blue-070
    }
    if (hoveredRegion === regionName) {
      return "rgb(209, 228, 255)"; // couple-blue-040
    }
    return "rgb(245, 245, 245)"; // couple-gray-010
  };

  if (loading) {
    return (
      <div className="w-full h-64 sm:h-80 bg-white rounded-lg border border-couple-gray-020 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-couple-blue-070 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
          <p className="couple-text-14-400 text-couple-gray-060">지도 로딩중...</p>
        </div>
      </div>
    );
  }

  if (!mapData) {
    return (
      <div className="w-full h-64 sm:h-80 bg-white rounded-lg border border-couple-gray-020 flex items-center justify-center">
        <p className="couple-text-14-400 text-couple-gray-060">지도 데이터를 로드할 수 없습니다</p>
      </div>
    );
  }

  return (
    <div className="w-full h-64 sm:h-80 bg-white rounded-lg border border-couple-gray-020">
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{
          center: [126.95, 37.55],
          scale: 80000,
          rotation: [0, 0, 0]
        }}
        width={800}
        height={600}
        className="w-full h-full"
      >
        <ZoomableGroup>
          <Geographies geography={mapData}>
            {({ geographies }) =>
              geographies.map(geo => {
                const regionName = geo.properties.SIG_KOR_NM;
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onClick={() => handleRegionClick(geo)}
                    onMouseEnter={() => setHoveredRegion(regionName)}
                    onMouseLeave={() => setHoveredRegion(null)}
                    style={{
                      default: {
                        fill: getRegionColor(regionName),
                        stroke: "rgb(133, 133, 133)",
                        strokeWidth: 0.5,
                        cursor: "pointer"
                      },
                      hover: {
                        fill: getRegionColor(regionName),
                        stroke: "rgb(31, 117, 255)",
                        strokeWidth: 1,
                        cursor: "pointer"
                      },
                      pressed: {
                        fill: "rgb(31, 117, 255)",
                        stroke: "rgb(31, 117, 255)",
                        strokeWidth: 1,
                        cursor: "pointer"
                      }
                    }}
                  />
                );
              })
            }
          </Geographies>
        </ZoomableGroup>
      </ComposableMap>
      
      {/* 선택된 지역 표시 */}
      {selectedRegion && (
        <div className="text-center mt-2">
          <span className="couple-text-12-500 text-couple-blue-070">
            선택된 지역: {selectedRegion}
          </span>
        </div>
      )}
    </div>
  );
};

export default SeoulMap;