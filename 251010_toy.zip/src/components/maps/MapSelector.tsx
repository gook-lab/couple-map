import React, { useState } from 'react';
import { ChevronLeft, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import SimpleSVGKoreaMap from './SimpleSVGKoreaMap';
import JapanMap from './JapanMap';
import SeoulMap from './SeoulMap';

export type MapType = 'selector' | 'korea' | 'seoul' | 'jeju' | 'japan';

interface MapSelectorProps {
  onLocationSelect?: (location: { type: MapType; region?: string; regionName?: string }) => void;
}

const MapSelector: React.FC<MapSelectorProps> = ({ onLocationSelect }) => {
  const [currentMap, setCurrentMap] = useState<MapType>('selector');
  const [selectedRegion, setSelectedRegion] = useState<string>('');

  const mapOptions = [
    {
      id: 'korea' as MapType,
      title: '전국 지도',
      description: '대한민국 전체',
      color: 'bg-couple-blue-010'
    },
    {
      id: 'seoul' as MapType,
      title: '서울 지도',
      description: '서울시 구별',
      color: 'bg-couple-blue-020'
    },
    {
      id: 'jeju' as MapType,
      title: '제주 지도',
      description: '제주특별자치도',
      color: 'bg-couple-blue-030'
    },
    {
      id: 'japan' as MapType,
      title: '일본 지도',
      description: '일본 주요 도시',
      color: 'bg-couple-blue-040'
    }
  ];

  const handleMapSelect = (mapType: MapType) => {
    setCurrentMap(mapType);
    setSelectedRegion('');
  };

  const handleRegionSelect = (regionId: string, regionName: string) => {
    setSelectedRegion(regionId);
    onLocationSelect?.({
      type: currentMap,
      region: regionId,
      regionName: regionName
    });
  };

  const handleBackToSelector = () => {
    setCurrentMap('selector');
    setSelectedRegion('');
  };

  const renderCurrentMap = () => {
    switch (currentMap) {
      case 'korea':
        return (
          <SimpleSVGKoreaMap
            onRegionClick={handleRegionSelect}
            selectedRegion={selectedRegion}
          />
        );
      case 'seoul':
        return (
          <SeoulMap
            onRegionClick={handleRegionSelect}
            selectedRegion={selectedRegion}
          />
        );
      case 'japan':
        return (
          <JapanMap
            onRegionClick={handleRegionSelect}
            selectedRegion={selectedRegion}
          />
        );
      case 'jeju':
        // 제주 지도는 간단하게 구현
        return (
          <div className="w-full h-64 sm:h-80 bg-couple-blue-010 rounded-lg border border-couple-gray-020 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-8 h-8 text-couple-blue-070 mx-auto mb-2" />
              <p className="couple-text-14-500 text-couple-gray-090">제주도 지도</p>
              <p className="couple-text-12-400 text-couple-gray-060 mt-1">곧 지원될 예정입니다</p>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  if (currentMap === 'selector') {
    return (
      <div className="space-y-4">
        <div className="text-center mb-6">
          <h2 className="couple-title-18 text-couple-gray-100 mb-2">
            지도 선택
          </h2>
          <p className="couple-text-14-400 text-couple-gray-060">
            여행하고 싶은 지역을 선택해주세요
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {mapOptions.map((option) => (
            <Card
              key={option.id}
              className="cursor-pointer transition-all hover:shadow-lg hover:border-couple-blue-040 active:scale-[0.98]"
              onClick={() => handleMapSelect(option.id)}
            >
              <CardContent className="p-4">
                <div className={`w-full h-32 ${option.color} rounded-lg mb-3 flex items-center justify-center`}>
                  <MapPin className="w-8 h-8 text-couple-blue-070" />
                </div>
                <h3 className="couple-text-16-600 text-couple-gray-090 mb-1">
                  {option.title}
                </h3>
                <p className="couple-text-12-400 text-couple-gray-060">
                  {option.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleBackToSelector}
          className="p-2"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <div>
          <h2 className="couple-title-16 text-couple-gray-100">
            {mapOptions.find(opt => opt.id === currentMap)?.title}
          </h2>
          <p className="couple-text-12-400 text-couple-gray-060">
            클릭하여 지역을 선택하세요
          </p>
        </div>
      </div>

      {renderCurrentMap()}

      {selectedRegion && (
        <div className="text-center p-4 bg-couple-blue-010 rounded-lg">
          <p className="couple-text-14-500 text-couple-blue-070">
            ✓ 지역이 선택되었습니다
          </p>
        </div>
      )}
    </div>
  );
};

export default MapSelector;