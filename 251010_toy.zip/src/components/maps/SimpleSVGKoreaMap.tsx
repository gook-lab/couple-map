import React, { useState } from 'react';

interface SimpleSVGKoreaMapProps {
  onRegionClick?: (regionId: string, regionName: string) => void;
  selectedRegion?: string;
}

const SimpleSVGKoreaMap: React.FC<SimpleSVGKoreaMapProps> = ({ onRegionClick, selectedRegion }) => {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const regions = [
    { id: 'seoul', name: '서울특별시', path: 'M150,120 L180,120 L180,140 L150,140 Z' },
    { id: 'gyeonggi', name: '경기도', path: 'M130,100 L200,100 L200,160 L130,160 Z' },
    { id: 'incheon', name: '인천광역시', path: 'M120,120 L150,120 L150,140 L120,140 Z' },
    { id: 'gangwon', name: '강원특별자치도', path: 'M200,80 L280,80 L280,140 L200,140 Z' },
    { id: 'chungbuk', name: '충청북도', path: 'M150,160 L220,160 L220,200 L150,200 Z' },
    { id: 'chungnam', name: '충청남도', path: 'M100,160 L150,160 L150,200 L100,200 Z' },
    { id: 'sejong', name: '세종특별자치시', path: 'M140,180 L160,180 L160,190 L140,190 Z' },
    { id: 'daejeon', name: '대전광역시', path: 'M130,190 L150,190 L150,200 L130,200 Z' },
    { id: 'jeonbuk', name: '전북특별자치도', path: 'M100,200 L170,200 L170,240 L100,240 Z' },
    { id: 'jeonnam', name: '전라남도', path: 'M80,240 L160,240 L160,300 L80,300 Z' },
    { id: 'gwangju', name: '광주광역시', path: 'M120,260 L140,260 L140,280 L120,280 Z' },
    { id: 'gyeongbuk', name: '경상북도', path: 'M220,140 L300,140 L300,220 L220,220 Z' },
    { id: 'gyeongnam', name: '경상남도', path: 'M180,220 L280,220 L280,280 L180,280 Z' },
    { id: 'daegu', name: '대구광역시', path: 'M240,200 L260,200 L260,220 L240,220 Z' },
    { id: 'ulsan', name: '울산광역시', path: 'M280,240 L300,240 L300,260 L280,260 Z' },
    { id: 'busan', name: '부산광역시', path: 'M260,260 L290,260 L290,280 L260,280 Z' },
    { id: 'jeju', name: '제주특별자치도', path: 'M80,320 L140,320 L140,350 L80,350 Z' }
  ];

  const handleRegionClick = (region: typeof regions[0]) => {
    onRegionClick?.(region.id, region.name);
  };

  const getRegionColor = (regionId: string) => {
    if (selectedRegion === regionId) {
      return "#1f75ff"; // couple-blue-070
    }
    if (hoveredRegion === regionId) {
      return "#d1e4ff"; // couple-blue-040
    }
    return "#f5f5f5"; // couple-gray-010
  };

  return (
    <div className="w-full h-64 sm:h-80 bg-white rounded-lg border border-couple-gray-020 flex items-center justify-center relative">
      <svg 
        width="400" 
        height="400" 
        viewBox="0 0 400 400"
        className="w-full h-full max-w-md max-h-80"
      >
        {regions.map((region) => (
          <path
            key={region.id}
            d={region.path}
            fill={getRegionColor(region.id)}
            stroke="#858585"
            strokeWidth="1"
            style={{ cursor: 'pointer' }}
            onClick={() => handleRegionClick(region)}
            onMouseEnter={() => setHoveredRegion(region.id)}
            onMouseLeave={() => setHoveredRegion(null)}
          />
        ))}
        
        {/* 지역명 표시 */}
        <text x="165" y="135" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">서울</text>
        <text x="135" y="135" fontSize="7" textAnchor="middle" fill="#666" pointerEvents="none">인천</text>
        <text x="165" y="155" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">경기</text>
        <text x="240" y="115" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">강원</text>
        <text x="185" y="185" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">충북</text>
        <text x="125" y="185" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">충남</text>
        <text x="135" y="225" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">전북</text>
        <text x="120" y="275" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">전남</text>
        <text x="130" y="270" fontSize="7" textAnchor="middle" fill="#666" pointerEvents="none">광주</text>
        <text x="260" y="185" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">경북</text>
        <text x="230" y="255" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">경남</text>
        <text x="250" y="215" fontSize="7" textAnchor="middle" fill="#666" pointerEvents="none">대구</text>
        <text x="290" y="255" fontSize="7" textAnchor="middle" fill="#666" pointerEvents="none">울산</text>
        <text x="275" y="275" fontSize="7" textAnchor="middle" fill="#666" pointerEvents="none">부산</text>
        <text x="110" y="340" fontSize="8" textAnchor="middle" fill="#666" pointerEvents="none">제주</text>
      </svg>
      
      {/* 선택된 지역 표시 */}
      {selectedRegion && (
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
          <span className="couple-text-12-500 text-couple-blue-070 bg-white px-2 py-1 rounded shadow">
            선택된 지역: {regions.find(r => r.id === selectedRegion)?.name}
          </span>
        </div>
      )}
    </div>
  );
};

export default SimpleSVGKoreaMap;